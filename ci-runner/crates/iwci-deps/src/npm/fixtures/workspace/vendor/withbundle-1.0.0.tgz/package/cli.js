#!/usr/bin/env node
console.log(require("./index.js"));
